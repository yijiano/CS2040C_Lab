#pragma once
#include <iostream>
#include <fstream>
#include <string>
// You can include/import any library/packages

using namespace std;

void partyGoing(string filename) {
    // Use these cout statments to make sure that your output is the same as our checker.

    cout << "For the file input of \"" << filename << "\"." << endl;
    int A, B, C, D;

    ifstream f(filename);
    if (!f.is_open())
    {
        cout << "File not found!" << endl;
        return;
    }

    f >> A >> B >> C >> D;

    for (int i = 0; i < B; i++) {
        // reading in the friendship
        int a, b;
        f >> a >> b;
        cout << "Student " << a << " is a friend of Student " << b << endl; // delete this line for submission
    }

    if (true)  // modify this condition
        cout << C << " will go for the party" << endl;
    else 
        cout << C << " will not go for the party" << endl;

    cout << "Classmate(s) who will go to the party is/are:" << endl;
    cout << "(Please a list of student number here, note that there is one more space after the last number.)" << endl;

}