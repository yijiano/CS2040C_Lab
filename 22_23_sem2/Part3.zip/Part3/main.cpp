#include "partygoing.h"

int main() {
    partyGoing("part3input0.txt");
    partyGoing("part3input0b.txt");
}