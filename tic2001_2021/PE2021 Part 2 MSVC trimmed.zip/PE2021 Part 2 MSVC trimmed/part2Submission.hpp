

template <class T>
void DHeap<T>::_bubbleUp(int index) {

}

template <class T>
void DHeap<T>::_bubbleDown(int index) {

}

template <class T>
T DHeap<T>::extractMax() {

    return T();

}


template <class T>
void DHeap<T>::insert(T item) {

}
