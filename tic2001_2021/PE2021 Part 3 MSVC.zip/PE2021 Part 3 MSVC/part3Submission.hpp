

void HashTable::insert(int n) {

    // default output format for error message
    //cout << n << " already exists in the hash table."<<endl;
}

//n does not necasarrily exist in the hash table
void HashTable::remove(int n) {
    // default output format for error message
    //cout << "Fail to remove " << n << endl;
}

bool HashTable::exist(int n) {
    return false;
}


void HashTable::resize(int newSize) {

}

int n3Sum(int* arr, int size, int total)
{
    return 0;
}
