#include <iostream>
#include "circularIntLinkedList.h"
using namespace std;

ListNode::ListNode(int n)
{
	_item = n;
	_next = NULL;
}


////////////////////////////////////////////////////////////////////////////
//      You should ONLY modify the bodies of the following functions      //
// You should copy and paste ALL the functions below onto coursemology    //
////////////////////////////////////////////////////////////////////////////

void CircularList::advanceHead()
{
	// modify this
}

void CircularList::insertHead(int n)
{
	// modify this
};

void CircularList::removeHead()
{
	// modify this
}

void CircularList::print() {
	// modify this
}

bool CircularList::exist(int n) {
	// modify this	
	return false;
}

int CircularList::headItem()
{
	// modify this
	return 0;
}

CircularList::~CircularList()
{
	// modify this
};

